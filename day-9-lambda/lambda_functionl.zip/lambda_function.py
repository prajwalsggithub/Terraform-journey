def lambda_handler(event, context):
    return {"statusCode": 200, "body": "Welcome toooooo to multicloud devops !"}